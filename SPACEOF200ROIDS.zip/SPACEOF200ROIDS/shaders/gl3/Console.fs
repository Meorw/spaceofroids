#version 150

out vec4 fragColor;

void main()
{
	fragColor = vec4(0.2, 0.4, 0.6, 0.5);
}
